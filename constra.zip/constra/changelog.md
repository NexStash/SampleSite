## Version 1.0.0 (2 sep 2019)
- Initial template
- Bootstrap version 3.3.7

## Version 2.0.0 (21 dec 2020)
- Bootstrap 4.5.3
- FontAwesome Free 5.13.1
- Slick Slider Added
- Sticky navbar issue solved
- Navbar mobile-menu animation added
- Projects style updated
- Google map updated
- Removed Owl-Carousel
- Removed Contact form php

## Version 2.1.0 (28 jul 2021)
- Fixed known responsive issues
